module.exports = {
    build: 1,
    version: "1.0.0"
};
