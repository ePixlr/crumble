require("colors");
const { build, version } = require("./info");
const connectDB = require("./src/dao/connectDB");
const Versioning = require("./src/dao/versioning");
const Users = require("./src/dao/users");
const Sessions = require("./src/dao/sessions");
const config = require("./config");
const Power = require("express-power");
const { log } = Power;

const master = async () => {
    console.log("");
    console.log("♥♥♥".green + " ♥♥♥".white + " ♥♥♥".red);
    console.log("♥♥♥".green + " ♥♥♥".white + " ♥♥♥".red);
    console.log("♥♥♥".green + " ♥♥♥".white + " ♥♥♥".red);
    console.log("");
    console.log("Honeyside".yellow);
    console.log(`Crumble v${version}`.yellow);
    console.log("");

    const isConnected = await connectDB();

    if (!isConnected) return;

    const info = await Versioning.getCurrentVersion();

    if (!info || info.build < build) {
        await Versioning.updateCurrentVersion({ version, build });
    }

    await Users.updateRootUser();
    await Sessions.deleteSessions();
}

const worker = async app => {
    const isConnected = await connectDB();
    if (!isConnected) return;

    const cors = require("cors");
    const formidable = require("express-formidable");
    const passport = require("passport");
    const jwtStrategy = require("./src/strategies/jwt");
    const routes = require("./src/routes");
    const xss = require("xss").filterXSS;
    const express = require("express");

    app.use(cors());

    app.use(express.static(`${__dirname}/../frontend/build`));
    app.use('/account', express.static(`${__dirname}/../frontend/build`));
    app.use('/vault', express.static(`${__dirname}/../frontend/build`));
    app.use('/users', express.static(`${__dirname}/../frontend/build`));
    app.use('/dashboard', express.static(`${__dirname}/../frontend/build`));
    app.use('/account', express.static(`${__dirname}/../frontend/build`));
    app.use('/docs', express.static(`${__dirname}/../frontend/build`));
    app.use('/keys', express.static(`${__dirname}/../frontend/build`));
    app.use('/auth/login', express.static(`${__dirname}/../frontend/build`));
    app.use('/auth/register', express.static(`${__dirname}/../frontend/build`));
    app.use('/login', express.static(`${__dirname}/../frontend/build`));
    app.use('/register', express.static(`${__dirname}/../frontend/build`));
    app.use('/404', express.static(`${__dirname}/../frontend/build`));

    app.use(formidable({maxFileSize: Number.MAX_SAFE_INTEGER}));
    app.use((req, res, next) => {
        Object.keys(req.fields).map(key => typeof req.fields[key] === 'string' && (req.fields[key] = xss(req.fields[key])));
        next();
    })
    app.use(passport.initialize({}));
    passport.use('jwt', jwtStrategy);
    app.use('/api', routes);

    app.use('*', express.static(`${__dirname}/../frontend/build`));

    app.listen(config.port, () => log(`listening on port ${config.port}`.green))
};

Power.load({ master, worker, logToFile: false });


