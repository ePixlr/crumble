const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const KeySchema = new Schema({
    user: {
        type: Schema.Types.ObjectId,
        ref: 'User',
    },
    userObject: {
        type: Object,
        ref: 'User',
    },
    title: {
        type: String,
        required: true,
    },
    date: {
        type: Date,
        default: Date.now
    },
    token: {
        type: String,
    },
});

const Key = mongoose.model('Key', KeySchema);

module.exports = Key;
