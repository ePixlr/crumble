const stats = require("../../dao/stats");

module.exports = async (req, res) => {
  let result;

  if (!req.user.roles.includes('admin') && !req.user.roles.includes('root')) {
    result = await stats.getFiles(req.user.id);
  } else {
    result = await stats.getFiles();
  }

  res.status(200).json(result);
};
