const { findKeys } = require("../../dao/keys");
const mongoose = require('mongoose');
const { ObjectId } = mongoose.Types;

module.exports = async (req, res) => {
    const { limit, text, sortField, sortOrder } = req.fields;

    let query = { user: ObjectId(req.user.id) };

    if (text) {
        query = {
            ...query,
            $and: [
                { title: { $regex: `.*${text}.*`, $options: 'i' }},
                { user: ObjectId(req.user.id) },
            ],
        };
    }

    let sort = { id: -1 };
    if (sortField) {
        sort = {};
        sort[sortField] = parseInt(sortOrder);
    }

    let keys;

    try {
        keys = await findKeys(query, sort, limit || 500);
        return res.status(200).json({ count: keys.length, keys });
    } catch (e) {
        return res.status(500).json({ status: "error", message: "database read error" });
    }
};
