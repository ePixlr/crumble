const { Strategy, ExtractJwt } = require('passport-jwt');
const config = require('../../config');
const secret = config.secret || 'default secret';
const Key = require('../models/Key');
const User = require('../models/User');
const Power = require('express-power');

module.exports = new Strategy({
  jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
  secretOrKey: secret
}, (payload, done) => {
  Power.log(`jwt auth user ${payload.username}`);
  if (payload.type === 'key') {
    Key.findById(payload.id).populate('user').lean()
      .then(key => {
        if (key.user) {
          return done(null, {
            id: key.user.id,
            username: key.user.username,
            email: key.user.email,
            roles: key.user.roles,
            firstName: key.user.firstName,
            lastName: key.user.lastName
          });
        }
        Power.log(`jwt auth key ${payload.id} failed`);
        return done(null, false);
      }).catch(err => {
      console.error(err);
      Power.log(`jwt auth key ${payload.id} error`.red);
    });
  } else {
    User.findById(payload.id)
      .then(user => {
        if (user) {
          return done(null, {
            id: user.id,
            username: user.username,
            email: user.email,
            roles: user.roles,
            firstName: user.firstName,
            lastName: user.lastName
          });
        }
        Power.log(`jwt auth user ${payload.username} failed`);
        return done(null, false);
      }).catch(err => {
      console.error(err);
      Power.log(`jwt auth user ${payload.username} error`.red);
    });
  }
});
