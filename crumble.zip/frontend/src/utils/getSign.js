function getSign(theNumber) {
  if (theNumber >= 0) {
    return '+';
  }
  return '-';
}

export default getSign;
