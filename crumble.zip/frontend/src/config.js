export default {
  url: process.env.REACT_APP_BACKEND_URL,
  demo: process.env.REACT_APP_DEMO === 'true',
  hideVersionInfo: process.env.REACT_APP_HIDE_VERSION_INFO === 'true',
};
