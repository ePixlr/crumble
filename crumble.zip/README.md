# Crumble - Private Enterprise Cloud Storage

Crumble is an enterprise cloud storage app with API capabilities. You can use Crumble to:
* Private users: store your files safely on your own server.
* Corporate users: store your files in a safe, redundant way and access them via enhanced search (by tag, by date, by description).
* Developers: store your application files and have them served securely to your users, with on-premise access tokens and expiring access!

## Honeyside Support
Welcome to the Honeyside experience! You can access the full [Crumble documentation online](https://docs.honeyside.it/crumble) and the [Honeyside Support Forum](https://forum.honeyside.it) is here for you. Also take a look at our [landing page](https://www.honeyside.it), because… well, it’s nice ❤

### Feature Requests

Support us on <a href="https://www.patreon.com/honeyside"><strong>Patreon</strong></a> to get priority updates on our development plan and <strong>voting power on new features</strong>.

## Versioning
We use SemVer for versioning. For the versions available, see the tags on this repository.

## License
This project is licensed under the Envato CodeCanyon Regular or Extended license, depending on which one you purchased.
